package com.example.postgesqlherokutest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostgesqlHerokuTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostgesqlHerokuTestApplication.class, args);
	}

}
